#!/usr/bin/env bash
set -eo pipefail
mkdir -p ~/.gradle/init.d
cp ci/force-sdk.gradle ~/.gradle/init.d/force-sdk.gradle
{
  flutter create --platforms=android --project-name lumora --org com.lumora .
  M=android/app/src/main/AndroidManifest.xml
  sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    <queries><intent><action android:name="android.speech.RecognitionService"/></intent></queries>\n    <application#' $M
  sed -i 's#android:label="[^"]*"#android:label="Lumora"#' $M
  sed -i 's#<application#<application android:usesCleartextTraffic="true"#' $M
  sed -i 's#</application>#<activity android:name="com.linusu.flutter_web_auth_2.CallbackActivity" android:exported="true"><intent-filter android:label="flutter_web_auth_2"><action android:name="android.intent.action.VIEW"/><category android:name="android.intent.category.DEFAULT"/><category android:name="android.intent.category.BROWSABLE"/><data android:scheme="lumora"/></intent-filter></activity>\n    </application>#' $M
  sed -i 's#<queries>#<queries><intent><action android:name="android.support.customtabs.action.CustomTabsService"/></intent>#' $M
  flutter pub get
  dart run flutter_launcher_icons
  flutter build apk --release
} 2>&1 | tee build.log
