import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'api.dart';
import 'chat_page.dart';
import 'store.dart';

// 'serif' and 'monospace' only exist on Android; iOS needs real font names.
final String serifFont =
    defaultTargetPlatform == TargetPlatform.iOS ? 'Georgia' : 'serif';
final String monoFont =
    defaultTargetPlatform == TargetPlatform.iOS ? 'Menlo' : 'monospace';

const accent = Color(0xFFC96442);
Color bg = const Color(0xFFFAF9F5);
Color ink = const Color(0xFF29261F);
Color line = const Color(0xFFE6E3D9);
Color soft = const Color(0xFFF0EEE6);
Color surf = Colors.white;
Color mut = const Color(0xFF6E6B63);
Color mut2 = const Color(0xFF8C897F);
Color btn = const Color(0xFF29261F);
Color onBtn = Colors.white;
Color heroBg = const Color(0xFF29261F);
void Function()? appRefresh;

void applyPalette(bool dark) {
  if (dark) {
    bg = const Color(0xFF191816);
    ink = const Color(0xFFEDEBE4);
    line = const Color(0xFF34312D);
    soft = const Color(0xFF2A2825);
    surf = const Color(0xFF232120);
    mut = const Color(0xFFA7A399);
    mut2 = const Color(0xFF7F7B72);
    btn = const Color(0xFFEDEBE4);
    onBtn = const Color(0xFF191816);
    heroBg = const Color(0xFF2D2A26);
  } else {
    bg = const Color(0xFFFAF9F5);
    ink = const Color(0xFF29261F);
    line = const Color(0xFFE6E3D9);
    soft = const Color(0xFFF0EEE6);
    surf = Colors.white;
    mut = const Color(0xFF6E6B63);
    mut2 = const Color(0xFF8C897F);
    btn = const Color(0xFF29261F);
    onBtn = Colors.white;
    heroBg = const Color(0xFF29261F);
  }
}

Future<void> main() async {
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (d) => FlutterError.presentError(d);
    // Show the real error instead of a blank / grey screen in release builds.
    ErrorWidget.builder = (d) => Directionality(
        textDirection: TextDirection.ltr,
        child: ColoredBox(
            color: const Color(0xFFFAF9F5),
            child: Padding(
                padding: const EdgeInsets.all(16),
                child: Center(
                    child: Text(d.exceptionAsString(),
                        style: const TextStyle(
                            color: Color(0xFF29261F), fontSize: 12))))));
    // Draw the first frame immediately; storage loads afterwards.
    runApp(const Boot());
  }, (e, s) => debugPrint('Unhandled: $e\n$s'));
}

/// Shows the logo at once, loads saved data with time limits, then opens the app.
class Boot extends StatefulWidget {
  const Boot({super.key});
  @override
  State<Boot> createState() => _BootState();
}

class _BootState extends State<Boot> {
  bool ready = false;
  String err = '';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    err = '';
    try {
      await Store.load().timeout(const Duration(seconds: 10));
    } catch (e) {
      err = 'Could not load saved data: $e';
    }
    try {
      await Api.load().timeout(const Duration(seconds: 10));
    } catch (e) {
      err += '${err.isEmpty ? '' : '\n'}Could not load API settings: $e';
    }
    if (!mounted) return;
    setState(() => ready = Store.ok);
    if (!Store.ok && err.isEmpty) {
      setState(() => err = 'Storage is not available.');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (ready) return const LumoraApp();
    final dark =
        WidgetsBinding.instance.platformDispatcher.platformBrightness ==
            Brightness.dark;
    final back = dark ? const Color(0xFF191816) : const Color(0xFFFAF9F5);
    final fore = dark ? const Color(0xFFEDEBE4) : const Color(0xFF29261F);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: back,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Image.asset('assets/logo.png', width: 120),
              const SizedBox(height: 24),
              if (err.isEmpty)
                const CircularProgressIndicator(color: accent)
              else ...[
                SelectableText(err,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: fore, fontSize: 13)),
                const SizedBox(height: 16),
                FilledButton(
                    onPressed: () {
                      setState(() => err = '');
                      _init();
                    },
                    child: const Text('Retry')),
              ],
            ]),
          ),
        ),
      ),
    );
  }
}

class LumoraApp extends StatefulWidget {
  const LumoraApp({super.key});
  @override
  State<LumoraApp> createState() => _LumoraAppState();
}

class _LumoraAppState extends State<LumoraApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    appRefresh = refresh;
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    if (Prefs.theme == 'system') refresh();
  }

  void _rebuild(Element e) {
    e.markNeedsBuild();
    e.visitChildren(_rebuild);
  }

  void refresh() {
    setState(() {});
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) (context as Element).visitChildren(_rebuild);
    });
  }

  bool get dark =>
      Prefs.theme == 'dark' ||
      (Prefs.theme == 'system' &&
          WidgetsBinding.instance.platformDispatcher.platformBrightness ==
              Brightness.dark);

  @override
  Widget build(BuildContext context) {
    final d = dark;
    applyPalette(d);
    final br = d ? Brightness.dark : Brightness.light;
    return MaterialApp(
      title: 'Lumora',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: br,
        scaffoldBackgroundColor: bg,
        colorScheme:
            ColorScheme.fromSeed(seedColor: accent, brightness: br, surface: bg),
        appBarTheme: AppBarTheme(
            backgroundColor: bg,
            elevation: 0,
            scrolledUnderElevation: 0,
            centerTitle: true,
            foregroundColor: ink,
            surfaceTintColor: Colors.transparent,
            systemOverlayStyle:
                d ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark),
        drawerTheme: DrawerThemeData(backgroundColor: bg),
      ),
      home: const ChatPage(),
    );
  }
}
