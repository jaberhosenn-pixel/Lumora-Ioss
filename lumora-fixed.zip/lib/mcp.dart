import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

/// MCP client: Streamable HTTP, plus the older SSE transport (URL ending in /sse).
class McpClient {
  final String url;
  String token;
  String? session;
  int _id = 0;
  Uri? _post;
  final _pend = <int, Completer<Map>>{};
  McpClient(this.url, this.token);

  bool get _legacy => Uri.parse(url).path.endsWith('/sse');
  Map<String, String> get _auth =>
      {if (token.isNotEmpty) 'Authorization': 'Bearer $token'};
  Map<String, String> get _h => {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream',
        ..._auth,
        if (session != null) 'Mcp-Session-Id': session!,
      };

  Never _fail(int code, String body) {
    if (code == 401 || code == 403) {
      throw Exception(
          'MCP $code: server needs a valid token (OAuth login is not supported).');
    }
    throw Exception('MCP HTTP $code: $body');
  }

  dynamic _result(Map msg) {
    if (msg['error'] != null) {
      throw Exception(msg['error']['message'] ?? 'MCP error');
    }
    return msg['result'];
  }

  Future<void> _open() async {
    final c = http.Client();
    final req = http.Request('GET', Uri.parse(url))
      ..headers.addAll({'Accept': 'text/event-stream', ..._auth});
    final res = await c.send(req);
    if (res.statusCode >= 400) _fail(res.statusCode, '');
    final ready = Completer<void>();
    var ev = '';
    res.stream
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen((l) {
      if (l.startsWith('event:')) {
        ev = l.substring(6).trim();
      } else if (l.startsWith('data:')) {
        final d = l.substring(5).trim();
        if (ev == 'endpoint') {
          _post = Uri.parse(url).resolve(d);
          if (!ready.isCompleted) ready.complete();
        } else {
          try {
            final j = jsonDecode(d);
            _pend.remove(j['id'])?.complete(Map.from(j));
          } catch (_) {}
        }
      }
    }, onError: (e) {
      if (!ready.isCompleted) ready.completeError(e);
    });
    await ready.future.timeout(const Duration(seconds: 15));
  }

  Future<dynamic> _rpc(String method,
      [Map<String, dynamic>? params, bool note = false]) async {
    final id = ++_id;
    final body = jsonEncode({
      'jsonrpc': '2.0',
      if (!note) 'id': id,
      'method': method,
      if (params != null) 'params': params,
    });
    if (_legacy) {
      if (_post == null) await _open();
      final c = Completer<Map>();
      if (!note) _pend[id] = c;
      final r = await http
          .post(_post!,
              headers: {'Content-Type': 'application/json', ..._auth},
              body: body)
          .timeout(const Duration(seconds: 30));
      if (r.statusCode >= 400) _fail(r.statusCode, r.body);
      if (note) return null;
      return _result(await c.future.timeout(const Duration(seconds: 60)));
    }
    final r = await http
        .post(Uri.parse(url), headers: _h, body: body)
        .timeout(const Duration(seconds: 60));
    if (r.statusCode >= 400) _fail(r.statusCode, r.body);
    session = r.headers['mcp-session-id'] ?? session;
    if (note || r.body.trim().isEmpty) return null;
    final text = utf8.decode(r.bodyBytes);
    Map? msg;
    if ((r.headers['content-type'] ?? '').contains('event-stream')) {
      for (final l in const LineSplitter().convert(text)) {
        if (!l.startsWith('data:')) continue;
        try {
          final j = jsonDecode(l.substring(5).trim());
          if (j is Map && j['id'] == id) msg = j;
        } catch (_) {}
      }
    } else {
      msg = jsonDecode(text);
    }
    if (msg == null) throw Exception('No MCP response');
    return _result(msg);
  }

  Future<void> init() async {
    await _rpc('initialize', {
      'protocolVersion': '2025-03-26',
      'capabilities': {},
      'clientInfo': {'name': 'Lumora', 'version': '1.0'}
    });
    await _rpc('notifications/initialized', null, true);
  }

  Future<List<Map<String, dynamic>>> tools() async {
    final r = await _rpc('tools/list');
    return (r['tools'] as List)
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  Future<String> call(String name, Map args) async {
    final r = await _rpc('tools/call', {'name': name, 'arguments': args});
    final c = (r['content'] as List?) ?? [];
    return c.map((e) => e['text']?.toString() ?? '[${e['type']}]').join('\n');
  }
}
