import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'main.dart';
import 'store.dart';
import 'ui.dart';

class ProjectsPage extends StatefulWidget {
  const ProjectsPage({super.key});
  @override
  State<ProjectsPage> createState() => _ProjectsPageState();
}

class _ProjectsPageState extends State<ProjectsPage> {
  Future<void> open(Project p) async {
    final r = await Navigator.push<Object>(
        context, MaterialPageRoute(builder: (_) => ProjectPage(p)));
    if (!mounted) return;
    setState(() {});
    if (r != null) Navigator.pop(context, r);
  }

  Future<void> create() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
              backgroundColor: bg,
              title: const Text('New project'),
              content: SingleChildScrollView(
                  child: uiField(c, 'Project name', hint: 'e.g. Website redesign')),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: accent),
                    onPressed: () => Navigator.pop(context, c.text),
                    child: const Text('Create')),
              ],
            ));
    if (name == null || name.trim().isEmpty) return;
    final p = Project(DateTime.now().millisecondsSinceEpoch.toString(), name.trim());
    Store.projects.insert(0, p);
    await Store.save();
    if (mounted) open(p);
  }

  @override
  Widget build(BuildContext context) => uiPage('Projects', [
        Padding(
            padding: EdgeInsets.only(bottom: 18, left: 4),
            child: Text(
                'A project keeps instructions, files and chats for one piece of work together. Lumora uses them in every chat inside the project.',
                style: TextStyle(color: mut, height: 1.4))),
        if (Store.projects.isEmpty)
          uiSection('', [
            uiRow('No projects yet',
                sub: 'Tap + to create your first project.',
                icon: Icons.folder_open)
          ])
        else
          uiSection('', [
            for (final p in Store.projects)
              uiRow(p.name,
                  sub:
                      '${p.files.length} files · ${Store.chats.where((c) => c.pid == p.id).length} chats',
                  icon: Icons.folder_open,
                  onTap: () => open(p),
                  trailing: Icon(Icons.chevron_right, color: mut2)),
          ]),
      ],
          fab: FloatingActionButton(
              backgroundColor: accent,
              foregroundColor: Colors.white,
              onPressed: create,
              child: const Icon(Icons.add)));
}

class ProjectPage extends StatefulWidget {
  final Project p;
  const ProjectPage(this.p, {super.key});
  @override
  State<ProjectPage> createState() => _ProjectPageState();
}

class _ProjectPageState extends State<ProjectPage> {
  late final nm = TextEditingController(text: widget.p.name);
  late final ins = TextEditingController(text: widget.p.instructions);

  @override
  void dispose() {
    widget.p.instructions = ins.text.trim();
    if (nm.text.trim().isNotEmpty) widget.p.name = nm.text.trim();
    Store.save();
    super.dispose();
  }

  Future<void> addFile() async {
    final r = await FilePicker.platform.pickFiles(withData: true);
    if (r == null || r.files.single.bytes == null) return;
    final f = r.files.single;
    var t = utf8.decode(f.bytes!, allowMalformed: true);
    if (t.length > 100000) t = t.substring(0, 100000);
    widget.p.files.add({'name': f.name, 'text': t});
    await Store.save();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final chats = Store.chats.where((c) => c.pid == widget.p.id).toList();
    return uiPage(widget.p.name, [
      uiField(nm, 'Project name'),
      uiField(ins, 'Instructions',
          lines: 5, hint: 'How should Lumora behave in this project?'),
      uiSection('Files', [
        if (widget.p.files.isEmpty)
          uiRow('No files yet',
              sub: 'Add text, code or notes Lumora should know.'),
        for (final f in widget.p.files)
          uiRow(f['name']!,
              sub: '${f['text']!.length} characters',
              icon: Icons.description_outlined,
              trailing: IconButton(
                  icon: const Icon(Icons.close, size: 20),
                  onPressed: () async {
                    widget.p.files.remove(f);
                    await Store.save();
                    setState(() {});
                  })),
        uiRow('Add file', icon: Icons.add, onTap: addFile),
      ]),
      uiSection('Chats in this project', [
        if (chats.isEmpty) uiRow('No chats yet'),
        for (final c in chats)
          uiRow(c.title,
              icon: modeIcon(c.mode),
              onTap: () => Navigator.pop(context, c)),
      ]),
      uiButton('New chat in this project', () => Navigator.pop(context, widget.p)),
      const SizedBox(height: 10),
      uiButton('Delete project', () async {
        final ok = await showDialog<bool>(
            context: context,
            builder: (_) => AlertDialog(
                  backgroundColor: bg,
                  title: const Text('Delete this project?'),
                  content: const Text('Its chats stay, but lose the project context.'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('Cancel')),
                    TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('Delete')),
                  ],
                ));
        if (ok == true) {
          for (final c in chats) {
            c.pid = null;
          }
          Store.projects.remove(widget.p);
          await Store.save();
          if (context.mounted) Navigator.pop(context);
        }
      }, primary: false, color: Colors.red.shade700),
    ]);
  }
}
