import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'api.dart';
import 'main.dart';
import 'pages.dart';
import 'store.dart';
import 'ui.dart';

Future<bool> confirmBox(BuildContext context, String title, String msg,
    {String ok = 'Confirm'}) async {
  final r = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
            backgroundColor: bg,
            title: Text(title),
            content: Text(msg),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Cancel')),
              TextButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: Text(ok, style: TextStyle(color: Colors.red.shade400))),
            ],
          ));
  return r == true;
}

Widget _chev() => Icon(Icons.chevron_right, color: mut2);

Widget _sw(String title, String sub, IconData icon, bool v, void Function(bool) on) =>
    uiRow(title,
        sub: sub.isEmpty ? null : sub,
        icon: icon,
        trailing: Switch(value: v, activeThumbColor: accent, onChanged: on));

class _Diag extends CustomClipper<Path> {
  @override
  Path getClip(Size s) => Path()
    ..moveTo(s.width, 0)
    ..lineTo(s.width, s.height)
    ..lineTo(0, s.height)
    ..close();
  @override
  bool shouldReclip(covariant CustomClipper<Path> o) => false;
}

Widget _mini(bool dark) {
  final b = dark ? const Color(0xFF191816) : const Color(0xFFFAF9F5);
  final g = dark ? const Color(0xFF6A675F) : const Color(0xFF8C897F);
  Widget bar(double w) => Container(
      height: 5,
      width: w,
      decoration:
          BoxDecoration(color: g, borderRadius: BorderRadius.circular(3)));
  return Container(
      color: b,
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        bar(54),
        const SizedBox(height: 6),
        bar(34),
        const Spacer(),
        const Align(
            alignment: Alignment.centerRight,
            child: CircleAvatar(radius: 8, backgroundColor: accent)),
      ]));
}

// ------------------------------------------------------------ Settings home
class SettingsHome extends StatefulWidget {
  const SettingsHome({super.key});
  @override
  State<SettingsHome> createState() => _SettingsHomeState();
}

class _SettingsHomeState extends State<SettingsHome> {
  Future<void> go(Widget w) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    if (mounted) setState(() {});
  }

  Widget modeCard(String label, String v, Widget preview) {
    final sel = Prefs.theme == v;
    return Expanded(
        child: GestureDetector(
            onTap: () async {
              Prefs.theme = v;
              await Prefs.save();
              appRefresh?.call();
              if (mounted) setState(() {});
            },
            child: Column(children: [
              Container(
                  height: 92,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                          color: sel ? accent : line, width: sel ? 2.5 : 1)),
                  child: preview),
              const SizedBox(height: 8),
              Text(label,
                  style: TextStyle(
                      color: sel ? accent : mut,
                      fontWeight: sel ? FontWeight.w600 : FontWeight.w400)),
            ])));
  }

  void fontSheet() => showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      builder: (sheet) => SafeArea(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 8),
            for (final f in const [
              ['serif', 'Serif (default)'],
              ['sans', 'Sans']
            ])
              uiRow(f[1],
                  trailing: Prefs.font == f[0]
                      ? const Icon(Icons.check, color: accent)
                      : null, onTap: () async {
                Prefs.font = f[0];
                await Prefs.save();
                if (sheet.mounted) Navigator.pop(sheet);
                appRefresh?.call();
              }),
            const SizedBox(height: 8),
          ])));

  @override
  Widget build(BuildContext context) => uiPage('Settings', [
        uiSection('Account', [
          uiRow('Profile',
              icon: Icons.person_outline,
              trailing: _chev(),
              onTap: () => go(const ProfilePage())),
          uiRow('API key',
              icon: Icons.key,
              trailing: _chev(),
              onTap: () => go(const SettingsPage())),
          uiRow('Usage and billing',
              icon: Icons.insights_outlined,
              trailing: _chev(),
              onTap: () => go(const DashboardPage())),
          uiRow('Privacy',
              icon: Icons.shield_outlined,
              trailing: _chev(),
              onTap: () => go(const PrivacyPage())),
          uiRow('Sharing and backup',
              icon: Icons.ios_share,
              trailing: _chev(),
              onTap: () => go(const SharingPage())),
        ]),
        uiSection('App', [
          uiRow('Capabilities',
              icon: Icons.tune,
              trailing: _chev(),
              onTap: () => go(const CapabilitiesPage())),
          uiRow('Connectors',
              icon: Icons.hub_outlined,
              trailing: _chev(),
              onTap: () => go(const ConnectorsPage())),
          uiRow('Persona and memory',
              icon: Icons.psychology_alt_outlined,
              trailing: _chev(),
              onTap: () => go(const PersonaPage())),
          uiRow('Prompt library',
              icon: Icons.bookmark_border,
              trailing: _chev(),
              onTap: () => go(const PromptsPage())),
          uiRow('Compare models',
              icon: Icons.compare_arrows,
              trailing: _chev(), onTap: () {
            if (Api.cached.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Add your API key first.')));
              return;
            }
            go(ComparePage(Api.cached));
          }),
          uiRow('Voice and dictation',
              icon: Icons.graphic_eq,
              trailing: _chev(),
              onTap: () => go(const VoicePage())),
          _sw('Haptic feedback', '', Icons.vibration, Prefs.haptics, (v) async {
            setState(() => Prefs.haptics = v);
            await Prefs.save();
            if (v) HapticFeedback.lightImpact();
          }),
        ]),
        uiSection('Appearance', [
          Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.dark_mode_outlined, color: ink),
                  const SizedBox(width: 14),
                  Text('Color mode', style: TextStyle(fontSize: 15.5, color: ink)),
                ]),
                const SizedBox(height: 14),
                Row(children: [
                  modeCard('Light', 'light', _mini(false)),
                  const SizedBox(width: 10),
                  modeCard('Dark', 'dark', _mini(true)),
                  const SizedBox(width: 10),
                  modeCard(
                      'System',
                      'system',
                      Stack(fit: StackFit.expand, children: [
                        _mini(false),
                        ClipPath(clipper: _Diag(), child: _mini(true)),
                      ])),
                ]),
              ])),
          uiRow('Font style',
              icon: Icons.text_fields,
              sub: Prefs.font == 'sans' ? 'Sans' : 'Serif (default)',
              trailing: _chev(),
              onTap: fontSheet),
        ]),
        uiSection('', [
          uiRow('Remove API key from this phone',
              icon: Icons.logout,
              color: Colors.red.shade400, onTap: () async {
            if (await confirmBox(context, 'Remove API key?',
                'Your chats stay. You can add the key again any time.',
                ok: 'Remove')) {
              await Api.save(Api.baseUrl, '');
              Api.cached = [];
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('API key removed.')));
              }
            }
          }),
        ]),
        Center(
            child: Text('Lumora 2.6',
                style: TextStyle(color: mut2, fontSize: 12.5))),
      ]);
}

// ------------------------------------------------------------------ Profile
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    final n = TextEditingController(text: Prefs.name);
    return uiPage('Profile', [
      Padding(
          padding: const EdgeInsets.only(bottom: 18, left: 4),
          child: Text(
              'Lumora uses your name in greetings and tells the model what to call you.',
              style: TextStyle(color: mut, height: 1.4))),
      uiField(n, 'Your name', hint: 'What should Lumora call you?',
          onChanged: (v) {
        Prefs.name = v.trim();
        Prefs.save();
      }),
      uiSection('', [
        uiRow('Persona and memory',
            sub: 'Style and facts Lumora should always keep in mind',
            icon: Icons.psychology_alt_outlined,
            trailing: _chev(),
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PersonaPage()))),
      ]),
    ]);
  }
}

// ------------------------------------------------------------- Capabilities
class CapabilitiesPage extends StatefulWidget {
  const CapabilitiesPage({super.key});
  @override
  State<CapabilitiesPage> createState() => _CapabilitiesPageState();
}

class _CapabilitiesPageState extends State<CapabilitiesPage> {
  void set(void Function() f) {
    setState(f);
    Prefs.save();
  }

  @override
  Widget build(BuildContext context) => uiPage('Capabilities', [
        uiSection('Chat', [
          _sw('Show which model answered',
              'A small note under each Auto reply', Icons.auto_awesome,
              Prefs.showNote, (v) => set(() => Prefs.showNote = v)),
          _sw('Token estimate while typing',
              'Shows an approximate input size above the buttons',
              Icons.numbers, Prefs.showEstimate,
              (v) => set(() => Prefs.showEstimate = v)),
        ]),
        uiSection('Tools', [
          _sw('Use connectors in chat',
              'Let Lumora call tools from your MCP connectors',
              Icons.hub_outlined, Prefs.useTools,
              (v) => set(() => Prefs.useTools = v)),
        ]),
      ]);
}

// -------------------------------------------------------- Voice and dictation
class VoicePage extends StatefulWidget {
  const VoicePage({super.key});
  @override
  State<VoicePage> createState() => _VoicePageState();
}

class _VoicePageState extends State<VoicePage> {
  @override
  Widget build(BuildContext context) => uiPage('Voice and dictation', [
        uiSection('', [
          uiRow('Language',
              icon: Icons.language,
              trailing: DropdownButton<String>(
                  value: Prefs.voiceLang,
                  underline: const SizedBox(),
                  items: const [
                    DropdownMenuItem(value: 'bn_BD', child: Text('Bengali')),
                    DropdownMenuItem(value: 'en_US', child: Text('English')),
                  ],
                  onChanged: (v) async {
                    setState(() => Prefs.voiceLang = v!);
                    await Prefs.save();
                  })),
          Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.speed, color: ink),
                  const SizedBox(width: 14),
                  Text('Speech speed', style: TextStyle(fontSize: 15.5, color: ink)),
                ]),
                Slider(
                    value: Prefs.voiceRate,
                    min: 0.25,
                    max: 1.0,
                    divisions: 15,
                    activeColor: accent,
                    onChanged: (v) => setState(() => Prefs.voiceRate = v),
                    onChangeEnd: (_) => Prefs.save()),
              ])),
        ]),
        Padding(
            padding: const EdgeInsets.only(left: 4),
            child: Text(
                'Dictation (mic) and live voice chat use these settings. If your phone has no Bengali voice installed, add it in the phone\'s text-to-speech settings.',
                style: TextStyle(fontSize: 12.5, color: mut2, height: 1.4))),
      ]);
}

// ------------------------------------------------------------------ Privacy
class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  Future<void> act(BuildContext context, String title, String msg,
      Future<void> Function() f) async {
    if (await confirmBox(context, title, msg, ok: 'Delete')) {
      await f();
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Done.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) => uiPage('Privacy', [
        Padding(
            padding: const EdgeInsets.only(bottom: 18, left: 4),
            child: Text(
                'Your chats, projects and settings are stored only on this phone. Messages go to your key system when you send them, and nowhere else.',
                style: TextStyle(color: mut, height: 1.4))),
        uiSection('Delete data', [
          uiRow('Clear all chats',
              icon: Icons.chat_bubble_outline,
              color: Colors.red.shade400,
              onTap: () => act(context, 'Clear all chats?', 'This cannot be undone.',
                  () async {
                Store.chats.clear();
                await Store.save();
              })),
          uiRow('Clear usage statistics',
              icon: Icons.bar_chart,
              color: Colors.red.shade400,
              onTap: () => act(context, 'Clear usage statistics?',
                  'The dashboard numbers on this phone will reset.', () async {
                Store.usage.clear();
                Store.monthly.clear();
                Store.daily.clear();
                await Store.save();
              })),
          uiRow('Delete all app data',
              icon: Icons.delete_forever_outlined,
              color: Colors.red.shade400,
              onTap: () => act(
                  context,
                  'Delete all app data?',
                  'Chats, projects, prompts, memory, connectors and usage will be erased. Your API key stays.',
                  () async {
                Store.importAll('{}');
                await Store.save();
              })),
        ]),
      ]);
}

// ------------------------------------------------------------------ Sharing
class SharingPage extends StatelessWidget {
  const SharingPage({super.key});
  @override
  Widget build(BuildContext context) => uiPage('Sharing and backup', [
        Padding(
            padding: const EdgeInsets.only(bottom: 18, left: 4),
            child: Text(
                'Backup copies everything (chats, projects, prompts, connectors, usage) as text. Paste it somewhere safe. Keep it private, it can contain connector tokens.',
                style: TextStyle(color: mut, height: 1.4))),
        uiSection('', [
          uiRow('Backup to clipboard', icon: Icons.upload_outlined, onTap: () async {
            await Clipboard.setData(ClipboardData(text: Store.exportAll()));
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Backup copied. Paste it in a safe place.')));
            }
          }),
          uiRow('Restore from clipboard', icon: Icons.download_outlined,
              onTap: () async {
            final d = await Clipboard.getData('text/plain');
            try {
              Store.importAll(d?.text ?? '');
              await Store.save();
              if (context.mounted) {
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('Restored.')));
              }
            } catch (_) {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('Clipboard has no valid backup.')));
              }
            }
          }),
        ]),
      ]);
}
