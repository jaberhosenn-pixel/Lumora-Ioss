import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class Msg {
  final bool user;
  String text;
  List<String> images;
  String note = '';
  bool err = false;
  Msg(this.user, this.text, [List<String>? i]) : images = i ?? [];
  Map<String, dynamic> toJson() =>
      {'u': user, 't': text, 'i': images, 'e': err};
  static Msg from(Map j) {
    final m = Msg(j['u'], j['t'], List<String>.from(j['i'] ?? []));
    m.err = j['e'] == true;
    return m;
  }
}

class Chat {
  String id, title, mode;
  String? pid;
  bool pinned;
  int ts;
  List<Msg> msgs;
  Chat(this.id, this.title, this.msgs,
      {this.mode = 'Chat', this.pid, this.pinned = false, int? ts})
      : ts = ts ?? (int.tryParse(id) ?? 0);
  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'm': msgs.map((e) => e.toJson()).toList(),
        'md': mode,
        'pid': pid,
        'pin': pinned,
        'ts': ts,
      };
  static Chat from(Map j) => Chat(
      j['id'], j['title'], (j['m'] as List).map((e) => Msg.from(e)).toList(),
      mode: j['md'] ?? 'Chat',
      pid: j['pid'],
      pinned: j['pin'] == true,
      ts: j['ts']);
}

class Project {
  String id, name, instructions;
  List<Map<String, String>> files;
  Project(this.id, this.name,
      {this.instructions = '', List<Map<String, String>>? files})
      : files = files ?? [];
  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'ins': instructions, 'files': files};
  static Project from(Map j) => Project(j['id'], j['name'],
      instructions: j['ins'] ?? '',
      files: ((j['files'] ?? []) as List)
          .map((e) => Map<String, String>.from(e))
          .toList());
}

class Prefs {
  static String theme = 'system', font = 'serif', voiceLang = 'bn_BD', name = '';
  static bool haptics = true, showNote = true, useTools = true, showEstimate = true;
  static double voiceRate = 0.5;

  static void load() {
    final s = Store.p.getString('prefs');
    if (s == null) return;
    try {
      final d = jsonDecode(s);
      theme = d['theme'] ?? theme;
      font = d['font'] ?? font;
      voiceLang = d['vl'] ?? voiceLang;
      name = d['name'] ?? name;
      haptics = d['hap'] ?? haptics;
      showNote = d['note'] ?? showNote;
      useTools = d['tools'] ?? useTools;
      showEstimate = d['est'] ?? showEstimate;
      voiceRate = ((d['rate'] ?? voiceRate) as num).toDouble();
    } catch (_) {}
  }

  static Future<void> save() => Store.p.setString(
      'prefs',
      jsonEncode({
        'theme': theme,
        'font': font,
        'vl': voiceLang,
        'name': name,
        'hap': haptics,
        'note': showNote,
        'tools': useTools,
        'est': showEstimate,
        'rate': voiceRate,
      }));
}

class Store {
  static late SharedPreferences p;
  static List<Chat> chats = [];
  static List<Project> projects = [];
  static List<String> prompts = [];
  static Map<String, dynamic> usage = {};
  static List<Map<String, dynamic>> mcps = [];
  static String persona = '', notes = '';
  static Map<String, int> monthly = {};
  static int limit = 0;
  static Map<String, dynamic> daily = {};
  static double priceIn = 0, priceOut = 0;

  static List<Chat> sorted() {
    final l = List<Chat>.of(chats);
    l.sort((a, b) {
      if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
      return b.ts.compareTo(a.ts);
    });
    return l;
  }

  static bool ok = false;

  static Future<void> load() async {
    p = await SharedPreferences.getInstance();
    ok = true;
    try {
      importAll(p.getString('all') ?? '{}');
    } catch (_) {
      // corrupted saved data must never block the app from opening
    }
    Prefs.load();
  }

  static String exportAll() => jsonEncode({
        'chats': chats.map((e) => e.toJson()).toList(),
        'projects': projects.map((e) => e.toJson()).toList(),
        'prompts': prompts,
        'usage': usage,
        'mcps': mcps,
        'persona': persona,
        'notes': notes,
        'monthly': monthly,
        'limit': limit,
        'daily': daily,
        'pin': priceIn,
        'pout': priceOut,
      });

  static void importAll(String s) {
    final d = jsonDecode(s);
    chats = ((d['chats'] ?? []) as List).map((e) => Chat.from(e)).toList();
    projects =
        ((d['projects'] ?? []) as List).map((e) => Project.from(e)).toList();
    prompts = List<String>.from(d['prompts'] ?? []);
    usage = Map<String, dynamic>.from(d['usage'] ?? {});
    persona = d['persona'] ?? '';
    notes = d['notes'] ?? '';
    monthly = Map<String, int>.from(d['monthly'] ?? {});
    limit = d['limit'] ?? 0;
    daily = Map<String, dynamic>.from(d['daily'] ?? {});
    priceIn = ((d['pin'] ?? 0) as num).toDouble();
    priceOut = ((d['pout'] ?? 0) as num).toDouble();
    mcps = ((d['mcps'] ?? []) as List)
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  static Future<void> save() => p.setString('all', exportAll());

  static void addUsage(String model, int i, int o) {
    final u =
        Map<String, dynamic>.from(usage[model] ?? {'i': 0, 'o': 0, 'n': 0});
    final mk = DateTime.now().toIso8601String().substring(0, 7);
    monthly[mk] = (monthly[mk] ?? 0) + i + o;
    final dk = DateTime.now().toIso8601String().substring(0, 10);
    final dd = Map<String, dynamic>.from(daily[dk] ?? {'i': 0, 'o': 0, 'n': 0});
    daily[dk] = {'i': dd['i'] + i, 'o': dd['o'] + o, 'n': dd['n'] + 1};
    usage[model] = {'i': u['i'] + i, 'o': u['o'] + o, 'n': u['n'] + 1};
  }
}
