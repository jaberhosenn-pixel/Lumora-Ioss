import 'package:flutter/material.dart';
import 'main.dart';

IconData modeIcon(String m) {
  switch (m) {
    case 'Code':
      return Icons.code;
    case 'Cowork':
      return Icons.work_outline;
    case 'Agent':
      return Icons.smart_toy_outlined;
    default:
      return Icons.chat_bubble_outline;
  }
}

Widget uiPage(String title, List<Widget> children,
        {Widget? fab, List<Widget>? actions}) =>
    Scaffold(
      appBar: AppBar(
        title: Text(title,
            style: TextStyle(
                fontFamily: serifFont, fontSize: 22, fontWeight: FontWeight.w600)),
        actions: actions,
      ),
      floatingActionButton: fab,
      body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 40), children: children),
    );

Widget uiSection(String label, List<Widget> rows, {String? note}) {
  final items = <Widget>[];
  for (var i = 0; i < rows.length; i++) {
    if (i > 0) {
      items.add(Divider(height: 1, indent: 16, endIndent: 16, color: line));
    }
    items.add(rows[i]);
  }
  return Padding(
    padding: const EdgeInsets.only(bottom: 22),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (label.isNotEmpty)
        Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 8),
            child: Text(label,
                style: TextStyle(
                    fontSize: 13,
                    color: mut,
                    fontWeight: FontWeight.w600))),
      Container(
          decoration: BoxDecoration(
              color: surf,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: line)),
          child: Column(children: items)),
      if (note != null)
        Padding(
            padding: const EdgeInsets.only(left: 4, top: 8),
            child: Text(note,
                style: TextStyle(
                    fontSize: 12.5, color: mut2, height: 1.4))),
    ]),
  );
}

Widget uiRow(String title,
        {String? sub,
        IconData? icon,
        Widget? trailing,
        VoidCallback? onTap,
        Color? color}) =>
    InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(children: [
            if (icon != null) ...[
              Icon(icon, size: 22, color: color ?? ink),
              const SizedBox(width: 14)
            ],
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(title,
                      style: TextStyle(fontSize: 15.5, color: color ?? ink)),
                  if (sub != null)
                    Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text(sub,
                            style: TextStyle(
                                fontSize: 13, color: mut, height: 1.3))),
                ])),
            if (trailing != null) trailing,
          ])),
    );

Widget uiVal(String v, {Color? c}) => ConstrainedBox(
    constraints: const BoxConstraints(maxWidth: 200),
    child: Text(v,
        overflow: TextOverflow.ellipsis,
        textAlign: TextAlign.right,
        style: TextStyle(fontWeight: FontWeight.w600, color: c ?? ink)));

Widget uiField(TextEditingController c, String label,
        {String? hint,
        bool obscure = false,
        int lines = 1,
        TextInputType? type,
        void Function(String)? onSubmitted,
        void Function(String)? onChanged,
        Widget? suffix}) =>
    Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 6),
            child: Text(label,
                style: TextStyle(
                    fontSize: 13,
                    color: mut,
                    fontWeight: FontWeight.w600))),
        TextField(
            controller: c,
            obscureText: obscure,
            minLines: lines,
            maxLines: obscure ? 1 : (lines == 1 ? 1 : lines + 4),
            keyboardType: type,
            onSubmitted: onSubmitted,
            onChanged: onChanged,
            decoration: InputDecoration(
                hintText: hint,
                filled: true,
                fillColor: surf,
                suffixIcon: suffix,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: line)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: accent, width: 1.5)))),
      ]),
    );

Widget uiButton(String label, VoidCallback? onTap,
        {bool primary = true, Color? color}) =>
    SizedBox(
        width: double.infinity,
        height: 50,
        child: primary
            ? FilledButton(
                style: FilledButton.styleFrom(
                    backgroundColor: accent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14))),
                onPressed: onTap,
                child: Text(label, style: const TextStyle(fontSize: 16)))
            : OutlinedButton(
                style: OutlinedButton.styleFrom(
                    foregroundColor: color ?? ink,
                    side: BorderSide(color: line),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14))),
                onPressed: onTap,
                child: Text(label, style: const TextStyle(fontSize: 16))));
